# Colors

Colors a is small interactive game in which the player is presented with a percentage
combination of colors in RGB components and based on that the player tries to guess
the correct color.
Basically, 
          You can think it like  mixing of three different colors red,Green and blue after which You will get another color.
