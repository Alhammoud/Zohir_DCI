# *Speed Typer*
___

This is a game which help you to improve your Typing speed. One-by-one random word will pop-up on your screen and you have to type those word before it disappear.
 Every word is moves from the left to right side of the canvas.
Words are gonna move faster depending upon how long you are going to survive. Get your hands darty with this game.


# Enjoy. Keep Learning :-) 
