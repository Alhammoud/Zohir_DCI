<SCRIPT LANGUAGE="JavaScript">
var ip = '<!--#echo var="REMOTE_ADDR"-->';
document.write("Your IP address is" + ip);
</script>