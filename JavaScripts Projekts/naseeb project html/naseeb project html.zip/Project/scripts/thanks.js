window.alert("Thank You For Signing With Us.");




function checkFormEntry ()
{     
 window.location.href="ownHome.html";
	
		
	
	return false;
}

document.getElementById("form1").onsubmit=checkFormEntry;	