

function checkFormEntry ()
{     
 window.location.href="buythanks.html";
	
		
	
	return false;
}

document.getElementById("form1").onsubmit=checkFormEntry;	