# component-state-update-from-another-component-in-react
How to update state of one component from another component in ReactJS
