#Flexbox - Exercise 3

Create a menu for mobile 0-600px. Each menu item should take up all the space on the row (one line). NOTE: Add style as needed, eg. borders etc.

Create a menu for desktop 600px+. Each menu item should be aligned side-by-side on the far right of the container.

See images for reference.
