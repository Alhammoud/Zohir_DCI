#Flexbox - Exercise 4

Use flexbox to style the page as seen in the images. 
HINT: Use order to style the largest breakpoint
